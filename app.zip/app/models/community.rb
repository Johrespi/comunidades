class Community < ApplicationRecord
  
  belongs_to :user

  has_many :users, dependent: :destroy
  has_many :events, dependent: :destroy

   # agregado César
  has_many :polls  

  validates :name, presence: true, uniqueness: true
  validates :description, presence: true 
  
  # AGREGADO LUIS INGA
  # Número de usuarios (miembros) en la comunidad
  def members_count
    users.count
  end

  # Número de eventos en la comunidad
  def events_count
    events.count
  end

  # Total de asistentes en todos los eventos de la comunidad
  def total_attendees_count
    events.joins(:event_attendees).count
  end

  # Promedio de asistentes por evento
  def average_attendees_per_event
    return 0 if events.empty?

    total_attendees_count / events.count.to_f
  end
end
